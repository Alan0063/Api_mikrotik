from flask import Flask, request, render_template
import paramiko

app = Flask(__name__)

# Detalles de conexión MikroTik
MIKROTIK_IP = '[fe80::a00:27ff:fed4:c49f%14]'
MIKROTIK_USER = 'admin'
MIKROTIK_PASS = 'admin'

def mikrotik_command(command):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(MIKROTIK_IP, port=22, username=MIKROTIK_USER, password=MIKROTIK_PASS)
        stdin, stdout, stderr = ssh.exec_command(command)
        result = stdout.read().decode()
        error = stderr.read().decode()
        if error:
            result += f"\nError: {error}"
    except paramiko.AuthenticationException:
        result = "Authentication failed."
    except Exception as e:
        result = f"Failed to execute command: {e}"
    finally:
        ssh.close()
    return result

def user_exists(username):
    command = f"/user print detail where name={username}"
    result = mikrotik_command(command)
    return f"name={username}" in result

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_user', methods=['POST'])
def add_user():
    username = request.form['username']
    password = request.form['password']
    group = request.form['group']
    
    if user_exists(username):
        return render_template('index.html', message="El usuario ya existe. Intente con otro nombre.")
    
    command = f"/user add name={username} password={password} group={group}"
    result = mikrotik_command(command)
    
    return render_template('index.html', message="Usuario agregado correctamente" if "Error" not in result else result)

@app.route('/add_ip', methods=['POST'])
def add_ip():
    ip_address = request.form['ip_address']
    interface = request.form.get('interface', 'ether1')
    upload_limit = request.form['upload_limit']
    download_limit = request.form['download_limit']

    # Añadir dirección IP
    ip_command = f"/ip address add address={ip_address} interface={interface}"
    ip_result = mikrotik_command(ip_command)
    
    # Configurar límites de ancho de banda
    queue_command = f"/queue simple add name={ip_address} target={ip_address} max-limit={upload_limit}k/{download_limit}k"
    bandwidth_result = mikrotik_command(queue_command)

    message = "IP y límite de ancho de banda agregados correctamente" if "Error" not in ip_result and "Error" not in bandwidth_result else f"{ip_result}\n{bandwidth_result}"
    return render_template('index.html', message=message)

@app.route('/change_bandwidth', methods=['POST'])
def change_bandwidth():
    ip_address = request.form['ip_address']
    new_upload_limit = request.form['new_upload_limit']
    new_download_limit = request.form['new_download_limit']

    # Comando para cambiar los límites de ancho de banda
    change_command = f"/queue simple set [find name={ip_address}] max-limit={new_upload_limit}k/{new_download_limit}k"
    change_result = mikrotik_command(change_command)

    message = "Ancho de banda cambiado correctamente" if "Error" not in change_result else change_result
    return render_template('index.html', message=message)

@app.route('/bandwidth', methods=['GET'])
def bandwidth():
    command = "/interface monitor-traffic interface=all once"
    result = mikrotik_command(command)
    
    return render_template('index.html', message=f"Consumo de ancho de banda: {result}" if "Error" not in result else result)

if __name__ == '__main__':
    app.run(debug=True)
